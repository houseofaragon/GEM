<div id="mobile-bar">
	<a class="menu-trigger" href="#"></a>
		<?php get_template_part('inc_section'); ?>
</div>