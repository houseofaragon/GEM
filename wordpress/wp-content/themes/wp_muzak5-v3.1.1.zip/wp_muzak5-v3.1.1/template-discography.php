<?php
/*
Template Name: Discography
*/
?>
<?php get_template_part('archive-cpt_discography'); ?>