<?php
/*
Template Name: Photo Galleries
*/
?>
<?php get_template_part('archive-cpt_galleries'); ?>