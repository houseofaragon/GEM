<?php
/*
Template Name: Artists
*/
?>
<?php get_template_part('archive-cpt_artists'); ?>