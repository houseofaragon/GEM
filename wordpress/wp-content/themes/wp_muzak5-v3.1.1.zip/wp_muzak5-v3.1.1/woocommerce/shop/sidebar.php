<div class="four columns omega sidebar">
	<?php dynamic_sidebar('shop-sidebar'); ?>
</div> <!-- #sidebar -->