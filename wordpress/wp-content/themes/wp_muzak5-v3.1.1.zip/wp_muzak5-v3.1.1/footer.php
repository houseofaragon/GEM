	</div><!-- /container -->

<!-- ########################### FOOTER ########################### -->
	<div id="footer-wrap">
		<div class="container">
			
			<footer id="footer" class="sixteen columns group">
				
				<div class="four columns widget-area alpha">
					<?php dynamic_sidebar('footer-sidebar-one'); ?>
				</div><!-- /widget-area -->
						
				<div class="four columns widget-area">
					<?php dynamic_sidebar('footer-sidebar-two'); ?>
				</div><!-- /widget-area -->	
					
				<div class="four columns widget-area">
					<?php dynamic_sidebar('footer-sidebar-three'); ?>
				</div><!-- /widget-area -->	
					
				<div class="four columns widget-area omega">
					<?php dynamic_sidebar('footer-sidebar-four'); ?>
				</div><!-- /widget-area -->	
					
			</footer><!-- /footer -->
		
		</div><!-- /container -->
	</div><!-- /footer-wrap -->
			
</div><!-- /wrap -->

<?php wp_footer(); ?>

</body>
</html>	